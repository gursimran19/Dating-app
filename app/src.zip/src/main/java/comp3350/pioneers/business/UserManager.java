/**
 * This class interacts with the persistance layer to fetch the user data
 * Builds and store the DSO object for the gui access
 */
package comp3350.pioneers.business;
import android.util.Log;

import java.util.List;

import comp3350.pioneers.persistence.all.IAllUsersPersistence;
import comp3350.pioneers.objects.*;

public class UserManager {

    private IAllUsersPersistence userDB = null;
    //private User userDSO;
    private MatchManager matchManager;
    //private List<Match> userMatches;  // Store matches

    public UserManager(MatchManager matchManager){
        this.userDB = Services.getUserDB();
        this.matchManager = matchManager;
    }

    public UserManager(IAllUsersPersistence userDB , MatchManager matchManager){
        this.userDB = userDB;
        this.matchManager = matchManager;
    }

    /**
     * Builds and stores the user DSO object globally for the application to access
     */
    public boolean buildUserDSO(String username, String password){
        //making sure valid input
        List<User> allUsers = userDB.getAllUsers();
        Log.d("UserManager", "Users in DB:");
        for (User u : allUsers) {
            System.out.println("UserManager:" + " " + u.getUsername() + " | " + u.getPassword());
            //Log.d("UserManager", " " + u.getUsername() + " | " + u.getPassword());
        }

        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            return false;
        }

        //create the user object
        User userDSO;
        try {
            userDSO = new User(username, password);
        } catch (IllegalArgumentException e) {
            return false;
        }

        boolean success = false;

        if(userDB.searchForUser(username)){
            try {
                //getting user from database
                String[] userBio = userDB.getUserBio(username);
                boolean matchType = userDB.getUserMatchType(username);

                //set bio if its not null
                if (userBio != null) {
                    userDSO.setUserBio(userBio);
                }

                userDSO.setUserMatchType(matchType);
                List<Match> userMatches = matchManager.getUserMatches(username);
                userDSO.setMatches(userMatches);
                System.out.println("set " + userMatches.size() + " matches for " + username);
                //Log.d("UserManager", "Set " + userMatches.size() + " matches for " + username);
                /*
                if(userMatches == null)
                    userMatches = new ArrayList<>();*/

                //userMatches = matchManager.getUserMatches(username);
                Services.addUserDSO(userDSO);

                success = true;
            } catch (Exception e) {
                // Log error or handle exception as needed
                System.out.println("UserManager Error in buildUserDSO: " + e.getMessage());
                //Log.e("UserManager", "Error in buildUserDSO: " + e.getMessage());
                success = false;
            }
        }

        return success;
    }

//    public String getUserNameFromDSO(){
//        User dso = Services.getUserDSO();
//        return dso.getUsername();
//    }



//    public String getBioFromDSO(){
//
//        User dso = Services.getUserDSO();
//        if(dso == null){
//            return null;
//        } else {
//            return dso.getUserBio();
//        }
//
//    }

    /*
    Returns:
    string[0] - interest1
    string[1] - interest2
    string[2] - interest3
    string[3] - interest4


     */
    public String[] getInterestsFromDSO(){
        User dso = Services.getUserDSO();
        return dso.getUserInterests();
    }


    public boolean updateUserBio(String username, String newbio, String interest1, String interest2, String interest3, String interest4){

        boolean success = false;
        User dso = Services.getUserDSO();
        String[] toUpdate = new String[5];
        if(username != null && newbio != null && interest1 != null && interest2 != null && interest3 != null && interest4 != null){
            toUpdate[0] = newbio;
            toUpdate[1] = interest1;
            toUpdate[2] = interest2;
            toUpdate[3] = interest3;
            toUpdate[4] = interest4;

            dso.setUserBio(toUpdate);
            success = userDB.updateUserBio(username,newbio);
            success = userDB.updateUserInterests(username, interest1,interest2,interest3,interest4);

        }

        return success;
    }

    public boolean updateUserMatchingType(String username, boolean romantic){
        boolean success = false;

        if(username != null && !username.isEmpty()){
            User userDso = Services.getUserDSO();

            success = userDB.updateMatchingType(username,romantic);
            if(success){
                userDso.setUserMatchType(romantic);
            }

        }

        return success;
    }
//    public User getUserFromDSO(){
//
//        return Services.getUserDSO();
//    }

    public boolean resetUserDso(){

        boolean success = false;
        Services.addUserDSO(null);

        if(Services.getUserDSO() == null){
            success = true;
        }

        return success;
    }

    public boolean getUserMatchType(){
        User userDSO = Services.getUserDSO();
        return userDSO.getUserMatchType();
    }

    // get random match from database
    public Match getRandomMatch(){
        User curr = Services.getUserDSO();

        return matchManager.getRandomMatch(curr.getUsername());
    }
    /*returns matches list*/
    /*public List<Match> getUserMatches(){
        if (userMatches == null) {
            //Log.e("ERROR", "userMatches is NULL in UserManager!");
            return new ArrayList<>(); //Prevent null crashes
        }
        return  userMatches;
    }*/


}
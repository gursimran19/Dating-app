package comp3350.pioneers.utils;

public class TestUtils {
//    private static final File DB_SRC = new File("src/main/assets/db/SC.script");
//
//    public static File copyDB() throws IOException {
//        File target = null;
//        try{
//
//            target = File.createTempFile("temp-db", ".script");
//            Files.copy(DB_SRC.toPath(), target.toPath());
//            Main.setDBPathName(target.getAbsolutePath().replace(".script",""));
//            String trg = target.getAbsolutePath();
//            System.out.println(trg);
//
//
//        } catch (IOException e) {
//            System.out.println("Problem in CopyDB:" + e.getMessage());
//
//        }
//
//
//        return target;
//    }

}

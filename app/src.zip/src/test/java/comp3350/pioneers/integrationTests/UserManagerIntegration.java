package comp3350.pioneers.integrationTests;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import java.io.File;

import comp3350.pioneers.business.MatchManager;
import comp3350.pioneers.business.Services;
import comp3350.pioneers.objects.Match;
import comp3350.pioneers.objects.User;
import comp3350.pioneers.persistence.all.IAllUsersPersistence;
import comp3350.pioneers.business.UserManager;
import comp3350.pioneers.persistence.all.IMatchPersistence;


/*
    Integration tests. Testing the UserManager classes ability to access the database and update Domain Specific Objects
    NOTE
    each call to the database opens and closes the connection to the database.
    So each test is independent, even though this is horribly inefficient. Will change for next iteration
    As of right now the actual database is being used to test. I could not for the life of me get
    The database to copy for testing purposes. Will fix for next iteration
 */
public class UserManagerIntegration {

    private IAllUsersPersistence userDb;
    private MatchManager matchMan;
    private IMatchPersistence matchDb;
    private UserManager userMan;
    private File tempDB;
    private static final File DB_SRC = new File("/data/user/0/comp3350.pioneers/app_db");

    @Before
    public void setUp(){

        try{

            //Main.setDBPathName("/data/user/0/comp3350.pioneers/app_db/SC");
            userDb = Services.getUserDB();

            matchDb = Services.getMatchDB();
            matchMan = new MatchManager(userDb,matchDb);

            User u1 = new User("person1","password1");
            User u2 = new User("person2","password2");
            User u3 = new User("person3","password3");
            User u4 = new User("person4","password4");
            userDb.addUserToDatabase(u1);
            userDb.addUserToDatabase(u2);
            userDb.addUserToDatabase(u3);
            userDb.addUserToDatabase(u4);

            userDb.updateUserBio("person1","Test Bio 1");
            userDb.updateUserInterests("person1","ski","hike","jog", "read");
            userDb.updateMatchingType("person1",false);
            userDb.updateUserInterests("person2","default1","default2","default3", "default4");
            userDb.updateUserBio("person2","Default bio");
            userDb.updateMatchingType("person2",true);
            //Injecting the persistence into the UserManager
            userMan = new UserManager(userDb,matchMan);

        } catch (Exception ioe){
            System.out.println("Error in setup " + ioe.getMessage());
        }

    }


    @Test
    public void buildUserDSO(){

        assertTrue(userMan.buildUserDSO("person1","person2"));
        assertFalse(userMan.buildUserDSO("Notindb","notindb"));
        assertFalse(userMan.buildUserDSO(null,null));
        assertFalse(userMan.buildUserDSO("",""));

    }

//    @Test
//    public void getUserNameFromDSO(){
//
//        assertTrue(userMan.buildUserDSO("person1","password1"));
//        assertEquals(userMan.getUserNameFromDSO(),"person1");
//
//    }

//    @Test
//    public void testGetBioFromDSO(){
//        assertTrue(userMan.buildUserDSO("person1","password1"));
//
//        String bio1 = userMan.getBioFromDSO();
//        assertEquals(bio1,"Test Bio 1");
//        assertTrue(userMan.resetUserDso());
//        //There should not be a user in the DSO, nothing to get.
//        assertNull(userMan.getBioFromDSO());
//
//
//    }
//    @Test
//    public void testGetInterestsFromDSO(){
//        assertTrue(userMan.buildUserDSO("person1","password1"));
//        String[] interests = userMan.getInterestsFromDSO();
//        assertEquals(interests[0],"ski");
//        assertEquals(interests[1],"hike");
//        assertEquals(interests[2],"jog");
//        assertEquals(interests[3],"read");
//
//    }

    /*
    REWRITE THESE TO GET USER DSO STUFF FROM SERVICES


     */
//    @Test
//    public void testUpdateUserBio(){
//        assertTrue(userMan.buildUserDSO("person2","password1"));
//        assertEquals(userMan.getBioFromDSO(),"Default bio");
//        assertTrue(userMan.updateUserBio("person2", "new bio 1","new interest 1", "new interest 2", "new interest 3", "new interest 4"));
//        String newBio = userMan.getBioFromDSO();
//        String[] newInterests = userMan.getInterestsFromDSO();
//        System.out.println("DA BIO IS " + newBio);
//        assertEquals("new bio 1", newBio);
//        assertEquals(newInterests[0],"new interest 1");
//        assertEquals(newInterests[1],"new interest 2");
//        assertEquals(newInterests[2],"new interest 3");
//        assertEquals(newInterests[3],"new interest 4");
//        assertFalse(userMan.updateUserBio(null,null,null,null,null,null));
//        assertFalse(userMan.updateUserBio("one",null,null,null,null,null));
//        assertFalse(userMan.updateUserBio(null,"notnull",null,null,null,null));
//        assertFalse(userMan.updateUserBio(null,null,"notnull",null,null,null));
//        assertFalse(userMan.updateUserBio(null,null,null,"notnull",null,null));
//        assertFalse(userMan.updateUserBio(null,null,null,null,"notnull",null));
//        assertFalse(userMan.updateUserBio(null,null,null,null,null,"notnull"));
//
//    }

    @Test
    public void testUpdateUserMatchType(){
        assertTrue(userMan.buildUserDSO("person2","password1"));
        assertTrue(userMan.getUserMatchType());
        assertTrue(userMan.updateUserMatchingType("person2",false));
        assertFalse(userMan.getUserMatchType());
        assertFalse(userMan.updateUserMatchingType("not in db",false));

    }

//    @Test
//    public void testGetUserFromDSO(){
//        assertTrue(userMan.buildUserDSO("person1","password1"));
//        User user = userMan.getUserFromDSO();
//        assertNotNull(user);
//        assertTrue(userMan.resetUserDso());
//        assertNull(userMan.getUserFromDSO());
//
//    }

    @Test
    public void testResetUserDso(){
        assertTrue(userMan.buildUserDSO("person1","password2"));
        assertNotNull(Services.getUserDSO());
        assertTrue(userMan.resetUserDso());
        assertNull(Services.getUserDSO());
    }
    @Test
    public  void testGetRandomMatch(){
        assertTrue(userMan.buildUserDSO("testUser", "testpassword"));
        Match testMatch = matchMan.getRandomMatch("testUser");

        if(testMatch != null){
            System.out.println("Random match - " + testMatch.getUserName());
            assertNotNull(testMatch.getUserName());
        }else {
            System.out.println("No match found for testUser");
        }
    }



}
